//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define DLG_MAIN                        101
#define MENU_MAIN                       102
#define MENU_POPUP_ITEMS                110
#define IDR_POPUP_ITEM                  112
#define IDC_ITEMTYPE                    1004
#define IDC_EDITOR_TREE                 1006
#define IDC_ITEM_PIC                    1007
#define IDC_EDITNAME                    1008
#define IDC_EDIT_NAME                   1008
#define IDC_EDITDESCR                   1010
#define IDC_EDIT_DESCR                  1010
#define IDC_EDITCID                     1012
#define IDC_EDIT_CID                    1012
#define IDC_SPINCID                     1013
#define IDC_SID                         1014
#define IDC_OPT_BLOCKING                1016
#define IDC_OPT_ATOP                    1017
#define IDC_EDIT_WEIGHT                 1018
#define IDC_OPT_STACKABLE               1019
#define IDC_OPT_USEABLE                 1020
#define IDC_OPT_NO_MOVE                 1021
#define IDC_OPT_PICKUP                  1022
#define IDC_OPT_ROTABLE                 1024
#define IDC_EDIT_DECAYTO                1025
#define IDC_COMBO_FLOOR                 1026
#define IDC_EDIT_DECAYTIME              1027
#define IDC_OPT_BLOCKPROJECTILE         1029
#define IDC_EDIT_ROTATETO               1030
#define IDC_COMBO_SLOT                  1031
#define IDC_EDIT_MAXITEMS               1032
#define IDC_COMBO_SKILL                 1033
#define IDC_COMBO_AMU                   1034
#define IDC_COMBO_SHOOT                 1035
#define IDC_EDIT_ATK                    1036
#define IDC_EDIT_DEF                    1037
#define IDC_EDIT_ARM                    1038
#define IDC_EDIT_READONLYID             1039
#define IDC_SET_CLIENT_OPT              1040
#define IDC_EDIT_SPEED                  1041
#define IDC_OPT_BLOCKPATHFIND           1042
#define IDC_OPT_HASHEIGHT               1043
#define IDC_EDIT_TOPORDER               1044
#define IDC_OPT_READABLE                1045
#define IDC_SAVE_ITEM                   1046
#define IDC_OPT_CANNOTDECAY             1047
#define IDC_OPT_DISTREAD                1048
#define IDC_COMBO_EDITOR                1049
#define IDC_EDIT_MAXTEXTLEN             1050
#define IDC_OPT_VERTICAL                1051
#define IDC_OPT_HORIZONTAL              1052
#define IDC_OPT_CORPSE                  1053
#define IDC_LIGHT_LEVEL                 1054
#define IDC_LIGHT_COLOR                 1055
#define ID_FILE_IMPORTXML               40001
#define ID_FILE_IMPORTOLD               40001
#define ID_FILE_IMPORTDAT               40002
#define ID_FILE_SAVEAS                  40003
#define ID_FILE_EXIT                    40004
#define ID_HELP_ABOUT                   40005
#define ID_TOOLS_VERIFYITEMS            40006
#define ID_TOOLS_CREATEMISSING          40007
#define ID_TOOLS_GOTOITEM               40008
#define ID_MENUG_CONTAINER              40011
#define ID_MENUG_WEAPON                 40012
#define ID_MENUG_AMMUNITION             40013
#define ID_MENUG_RUNE                   40015
#define ID_MENUG_TELEPORT               40016
#define ID_MENUG_MAGICFIELD             40017
#define ID_MENUG_WRITEABLE              40018
#define ID_MENUG_KEY                    40019
#define ID_MENUG_SPLASH                 40020
#define ID_MENUG_FLUID                  40021
#define ID_MENUG_NONE                   40022
#define ID_MENUG_GROUND                 40023
#define ID_MENUG_ARMOR                  40024
#define ID_FILE_LOADOTB                 40027
#define ID_FILE_NEWIT                   40031
#define ID_TOOLS_AUTOFIND               40032
#define ID_TOOLS_SHOWNOTFOUN            40033
#define ID_TOOLS_SHOWALL                40034
#define ID_TOOLS_IMPORTXMLNAMES         40035
#define ID_TOOLS_EXPORTXMLNAMES         40036
#define ID_MENUG_DOOR                   40037
#define ID_TOOLS_ADDITEM                40038

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40040
#define _APS_NEXT_CONTROL_VALUE         1056
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
